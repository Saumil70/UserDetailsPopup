﻿using Microsoft.AspNetCore.Mvc;
using UserDetailsPopup.Models;
using UserDetailsPopup.Repository.IRepository;

namespace UserDetailsPopup.Controllers
{
    public class UserManagerController : Controller
    {
        
        private readonly IUnitOfWork _unitOfWork;
        private readonly IWebHostEnvironment _webHostEnvironment;
        public UserManagerController(IUnitOfWork db, IWebHostEnvironment webHostEnvironment)
        {
            _unitOfWork = db;
            _webHostEnvironment = webHostEnvironment;
        }

        public IActionResult Index()
        {
            return View();
        }

        public JsonResult UserList()
        {
            var data = _unitOfWork.UserRepository.UserIndex().ToList();
            return Json(data);
        }

        public JsonResult CountryList()
        {
            var data = _unitOfWork.CountryRepository.GetAll().ToList();
            return Json(data);

        }
        public JsonResult StateList(int countryId)
        {
            var data = _unitOfWork.StateRepository.GetAll().Where(u => u.CountryId == countryId);
            return Json(data); // Return states as JSON

        }
        public JsonResult CityList(int stateId)
        {
            var data = _unitOfWork.CityRepository.GetAll().Where(u => u.StateId == stateId);
            return Json(data); // Return states as JSON

        }
        public JsonResult DepartmentList()
        {
            var data = _unitOfWork.DepartmentRepository.GetAll().ToList();
            return Json(data);

        }

        [HttpPost]
        public JsonResult AddUser(Employee user, IFormFile? file)
        {
            if(ModelState.IsValid)
            {
                string wwwRootPath = _webHostEnvironment.WebRootPath;

                if (file != null)
                {
                    var fileName = Path.GetFileName(file.FileName);
                    var uploads = Path.Combine(wwwRootPath, "Images");
                    var filePath = Path.Combine(uploads, fileName);


                    if (!string.IsNullOrEmpty(user.ImageUrl))
                    {
                        var oldImagePath = Path.Combine(wwwRootPath, user.ImageUrl.TrimStart('\\'));

                        if (System.IO.File.Exists(oldImagePath))
                        {
                            System.IO.File.Delete(oldImagePath);
                        }
                    }

                    using (var fileStream = new FileStream(filePath, FileMode.Create))
                    {
                        file.CopyTo(fileStream);
                    }

                    user.ImageUrl = @"\Images\" + fileName;
                }

                var obj = new Employee
                {
                    Name = user.Name,
                    Email = user.Email,
                    Address = user.Address,
                    Hobbies = user.Hobbies,
                    DepartmentId = user.DepartmentId,
                    GenderId = user.GenderId,
                    CountryId = user.CountryId,
                    CityId = user.CityId,
                    StateId = user.StateId,
                    ImageUrl = user.ImageUrl
                };
                _unitOfWork.UserRepository.UserAdd(obj);
                _unitOfWork.Save();
                return new JsonResult(new { success = true });
            }
            else
            {
                return new JsonResult(new {success = false});
            }
            
        }
        public JsonResult Edit(int id)
        {
            var data = _unitOfWork.UserRepository.Get(c => c.EmployeeId == id);
            return new JsonResult(data);
        }

        [HttpPost]
        public JsonResult EditUser(Employee user, IFormFile? file)
        {
            if (ModelState.IsValid)
            {
                string wwwRootPath = _webHostEnvironment.WebRootPath;

                if (file != null)
                {
                    var fileName = Path.GetFileName(file.FileName);
                    var uploads = Path.Combine(wwwRootPath, "Images");
                    var filePath = Path.Combine(uploads, fileName);
                    

                    if (!string.IsNullOrEmpty(user.ImageUrl))
                    {
                        var oldImagePath = Path.Combine(wwwRootPath, user.ImageUrl.TrimStart('\\'));

                        if (System.IO.File.Exists(oldImagePath))
                        {
                            System.IO.File.Delete(oldImagePath);
                        }
                    }

                    using (var fileStream = new FileStream(filePath, FileMode.Create))
                    {
                        file.CopyTo(fileStream);
                    }

                    user.ImageUrl = @"\Images\" + fileName;
                }
                _unitOfWork.UserRepository.UserUpdate(user);
                _unitOfWork.Save();
                return new JsonResult(new {success = true});
            }
            else
            {
                return new JsonResult(new { success = false });
            }
            
        }

        public JsonResult Delete(int id)
        {
            var user = _unitOfWork.UserRepository.Get(c => c.EmployeeId == id);
            _unitOfWork.UserRepository.UserDelete(user);
            _unitOfWork.Save();
            return new JsonResult("User Deleted Successfully");
        }
    }
}
